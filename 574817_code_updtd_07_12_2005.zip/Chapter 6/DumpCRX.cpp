// DumpCRX.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include "windows.h"
#include "cryptex.h"

CRYPTEX_ARCHIVE CurrentHeader;
CRYPTEX_DIRECTORY_CLUSTER CurrentCluster;
HCRYPTPROV hProv;
BYTE KeySignature[16];

BOOL ReadHeader(HANDLE hArchiveFile)
{
  DWORD dwBytesRead;
  SetFilePointer(hArchiveFile, 0, 0, FILE_BEGIN); 
  return ReadFile(hArchiveFile, &CurrentHeader, sizeof(CurrentHeader), &dwBytesRead, NULL);
} 

BOOL SeekToCluster(HANDLE hArchiveFile, ULONG ClusterNumber)
{
  unsigned __int64 ByteOffset;
  ByteOffset = (unsigned __int64) sizeof(CRYPTEX_ARCHIVE) + (unsigned __int64) (ClusterNumber - 1) * (unsigned __int64) TOTAL_CLUSTER_SIZE;
  LONG HiWord = (LONG) (ByteOffset >> 32);
  return SetFilePointer(hArchiveFile, (ULONG) ByteOffset, &HiWord, FILE_BEGIN); 
}

PCRYPTEX_DIRECTORY_CLUSTER ReadCluster(HANDLE hArchiveFile, ULONG ClusterNumber, HCRYPTKEY hKey)
{
  DWORD dwBytesRead;
  SeekToCluster(hArchiveFile, ClusterNumber);
  if (ReadFile(hArchiveFile, &CurrentCluster, sizeof(CurrentCluster), &dwBytesRead, NULL))
  {
    DWORD dwBytesRead = TOTAL_CLUSTER_SIZE;
    if (hKey && CryptDecrypt(hKey, NULL, TRUE, 0, (PBYTE) &CurrentCluster, &dwBytesRead) == FALSE)
    {
      DWORD dwErr = GetLastError();      
      printf ("ERROR: Unable to decrypt cluster %d.\n", ClusterNumber);
      exit(1);
    }    

    return &CurrentCluster;
  }
  else
    return NULL;
} 

ULONG ListFileDescriptors(HANDLE hArchiveFile, HCRYPTKEY hKey)
{
  DWORD CurrentClusterIndex, CurrentDescriptor = 0;
  DWORD dwBytesRead = 0;
  ULONG TotalFilesListed = 0;
  ReadHeader(hArchiveFile);
  ReadCluster(hArchiveFile, CurrentHeader.FileTableCluster, hKey);
  CurrentClusterIndex = CurrentHeader.FileTableCluster;
  PCRYPTEX_DIRECTORY_CLUSTER pCurrentDirCluster = (PCRYPTEX_DIRECTORY_CLUSTER) &CurrentCluster;
    
  while (CurrentClusterIndex)
  {
    while (CurrentDescriptor < DESCRIPTORS_PER_CLUSTER)
    {      
      if (pCurrentDirCluster->Contents.Descriptors[CurrentDescriptor].SizeInClusters)
      {
        printf ("%s (%dK)\n", pCurrentDirCluster->Contents.Descriptors[CurrentDescriptor].szName,
          pCurrentDirCluster->Contents.Descriptors[CurrentDescriptor].SizeInClusters * CLUSTER_PAYLOAD_SIZE / 1024);
                      
        TotalFilesListed++; 
       }
        
      CurrentDescriptor++;
    }
    CurrentClusterIndex = pCurrentDirCluster->dwNextCluster;
    if (CurrentClusterIndex)
      pCurrentDirCluster = (PCRYPTEX_DIRECTORY_CLUSTER) ReadCluster(hArchiveFile, CurrentClusterIndex, hKey);
    
    CurrentDescriptor = 0;
  }
  
  return TotalFilesListed;
}

BOOL VerifyHeader(HANDLE hArchiveFile)
{
  if (ReadHeader(hArchiveFile) == FALSE)
    return FALSE;
    
  if (CurrentHeader.Signature1 != SIGNATURE1 || CurrentHeader.Signature2 != SIGNATURE2)
    return FALSE;
     
  if (memcmp(CurrentHeader.KeySignature, KeySignature, 16))
    return FALSE;
    
  return TRUE;
}

HANDLE OpenArchive(HCRYPTKEY hKey, LPSTR pszArchiveName)
{
    char szFullName[1024];
    HANDLE hArchiveFile = NULL;

    strcpy(szFullName, pszArchiveName);
    LPSTR pszCleanFileName = pszArchiveName;
    while (pszArchiveName = strchr(pszArchiveName, '\\'))
    {
      pszArchiveName++;
      pszCleanFileName = pszArchiveName;
    } 
    
    hArchiveFile = CreateFile(szFullName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, NULL);
    if (hArchiveFile == INVALID_HANDLE_VALUE)
    {
      printf ("Cannot find Cryptex archive \"%s\"!\n", szFullName);
      exit(1);    
    }
    else
    {
      if (VerifyHeader(hArchiveFile) == FALSE)
      {
        printf ("Invalid Cryptex archive!\n");
        exit(1);
      }
    }
    
    return hArchiveFile;
}

BOOL HashKey(PBYTE pbKeyData, PBYTE pResultingHash)
{
  HCRYPTHASH hHash;
  if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash) == FALSE)
    return FALSE;
  
  if (CryptHashData(hHash, (PBYTE) pbKeyData, 20, 0) == FALSE)
  {
    CryptDestroyHash(hHash);
    return FALSE;
  }
  
  ULONG HashLength = 16;
  BOOL bResult = CryptGetHashParam(hHash, HP_HASHVAL, pResultingHash, &HashLength, 0);
  
  CryptDestroyHash(hHash);
  
  return bResult;    
}

HCRYPTKEY ComputeKeyFromPassword(HCRYPTPROV hProv, LPSTR pszPassword)
{
  HCRYPTHASH hHash;
  if (CryptCreateHash(hProv, CALG_SHA, 0, 0, &hHash) == FALSE)
    return NULL;
  
  if (CryptHashData(hHash, (PBYTE) pszPassword, (DWORD) strlen(pszPassword), 0) == FALSE)
  {
    CryptDestroyHash(hHash);
    return NULL;
  }
  
  BYTE SHAHash[20] = { 0 };
  ULONG HashLength = 20;
  if (CryptGetHashParam(hHash, HP_HASHVAL, SHAHash, &HashLength, 0) == FALSE)
    printf ("Unable to obtain MD5 hash value for file.\n");
    
  if (HashKey(SHAHash, KeySignature) == FALSE)
  {
    CryptDestroyHash(hHash);
    return NULL;
  }
  
  HCRYPTKEY hKey = NULL;
  CryptDeriveKey(hProv, CALG_3DES, hHash, 0, &hKey);
  
  CryptDestroyHash(hHash);
  return hKey; 
}

int main(int argc, char* argv[])
{
  if (argc != 3)
  {
    printf ("DumpCRX: Specify archive name and password.\n");
    exit(1);    
  }
  
  if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT))
  {
    printf ("Unable to initialize the Cryptographic Service Provider!\n");
    exit(1);
  }
  
  HCRYPTKEY hKey = ComputeKeyFromPassword(hProv, argv[2]);
  HANDLE hArchive = OpenArchive(hKey, argv[1]);
  
  printf ("List of files in archive %s:\n", argv[1]);
  
  ListFileDescriptors(hArchive, hKey);
  
    if (hKey)
    CryptDestroyKey(hKey);
    
  CryptReleaseContext(hProv, 0);
  
	return 0;
}

