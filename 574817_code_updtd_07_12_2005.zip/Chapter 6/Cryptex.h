#pragma once

#define TOTAL_CLUSTER_SIZE    4104
#define CLUSTER_PAYLOAD_SIZE  4092

#define FILE_NAME_LENGTH 128
#define SIGNATURE1 0x70597243
#define SIGNATURE2 0x39586554

typedef struct _CRYPTEX_ARCHIVE
{
  DWORD   Signature1;
  DWORD   Signature2;
  DWORD   dwUnknown1;
  DWORD   FileTableCluster;
  DWORD   dwUnknown2;
  DWORD   dwUnknown3;
  BYTE    KeySignature[16];
} CRYPTEX_ARCHIVE, *PCRYPTEX_ARCHIVE;

typedef struct _CRYPTEX_FILE_DESCRIPTOR
{
  DWORD   Unknown;
  DWORD   SizeInClusters;
  DWORD   MD5Hash[4];
  CHAR    szName[FILE_NAME_LENGTH];
} CRYPTEX_FILE_DESCRIPTOR, *PCRYPTEX_FILE_DESCRIPTOR;

typedef struct _CRYPTEX_DIRECTORY_CLUSTER
{  
  DWORD   dwNextCluster;
  union
  {
    CRYPTEX_FILE_DESCRIPTOR Descriptors[CLUSTER_PAYLOAD_SIZE / sizeof(CRYPTEX_FILE_DESCRIPTOR)];
    char                    Data[TOTAL_CLUSTER_SIZE - 4];  // Just to make sure the cluster has the right size.
  } Contents;
} CRYPTEX_DIRECTORY_CLUSTER, *PCRYPTEX_DIRECTORY_CLUSTER;

#define DESCRIPTORS_PER_CLUSTER (CLUSTER_PAYLOAD_SIZE / sizeof(CRYPTEX_FILE_DESCRIPTOR))