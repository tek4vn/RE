The virus executable stored in this directory has been encrypted using
the Cryptex program from Chapter 6. In order to decrypt it you must launch
Cryptex.exe with the password "becareful". For example, assuming that Cryptex
and the encrypted virus archive are in the same directory, the command should 
be: cryptex x HackArmy becareful "Webcam Shots.scr_REMOVE_THIS"

Once the file is properly decrypted, its executable extension must be restored
so that it is once again treated as an executable binary by Windows (it should
be renamed to something like "Webcam Shots.scr". Again, this program should only
be launched on a system that is safely detached from the network and one that 
contains no valuable information.

Happy digging!