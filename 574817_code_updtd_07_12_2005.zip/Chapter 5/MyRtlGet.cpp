#include <windows.h>
#include "generictable.h"

// This is the reconstructed implementation of RtlGetElementGenericTable.
// Build this file using the Release configuration to obtain the same code as
// presented in the book (taken from Windows XP Service Pack 2).

PVOID __stdcall MyRtlGetElementGenericTable(TABLE *Table, ULONG ElementToGet)
{
  ULONG TotalElementCount = Table->NumberOfElements;
  LIST_ENTRY *ElementFound = Table->LastElementFound;
  ULONG LastElementFound = Table->LastElementIndex;
  ULONG AdjustedElementToGet = ElementToGet + 1;

  if (ElementToGet == -1 || AdjustedElementToGet > TotalElementCount)
    return 0;

  // If our element is the last element found, we just return it.
  if (AdjustedElementToGet != LastElementFound)
  {
    // If our element isn't LastElementFound, go search for it:
    if (LastElementFound > AdjustedElementToGet)
    {
      // Our element is located somewhere between the first element and 
      // the LastElementIndex. Let's determine which direction would 
      // get us there the fastest.
      ULONG HalfWayFromLastFound = LastElementFound / 2;
      if (AdjustedElementToGet > HalfWayFromLastFound)
      {
        // We start at LastElementFound (because we're closer to it) and 
        // move backwards towards the beginning of the list.
        ULONG ElementsToGo = LastElementFound - AdjustedElementToGet;
        
        while(ElementsToGo--)
          ElementFound = ElementFound->Blink;        
      }
      else
      {
        // We start at the beginning of the list and move forward:
        ULONG ElementsToGo = AdjustedElementToGet;
        ElementFound = (LIST_ENTRY *) &Table->LLHead;
        
        while(ElementsToGo--)
          ElementFound = ElementFound->Flink;        
      }
    }
    else
    {
      // Our element has a higher index than LastElementIndex. Let's see
      // if it's closer to the end of the list or to LastElementIndex:
      ULONG ElementsToLastFound = AdjustedElementToGet - LastElementFound;
      ULONG ElementsToEnd = TotalElementCount - AdjustedElementToGet+ 1;

      if (ElementsToLastFound <= ElementsToEnd)
      {
        // Our element is closer (or at the same distance) to the last
        // element found than to the end of the list. We traverse the 
        // list forward starting at LastElementFound.
        while (ElementsToLastFound--)
          ElementFound = ElementFound->Flink;          
      }
      else
      {
        // Our element is closer to the end of the list than to the last 
        // element found. We start at the head pointer and traverse the 
        // list backwards.
        ElementFound = (LIST_ENTRY *) &Table->LLHead;
        while (ElementsToEnd--)
          ElementFound = ElementFound->Blink;
      }
    }

    // Cache the element for next time.    
    Table->LastElementFound = ElementFound;
    Table->LastElementIndex = AdjustedElementToGet;
  }

  // Skip the header and return our element.
  // Note that we don't have a full definition for the element struct 
  // yet, so I'm just incrementing by 3 ULONGs.
  return (PVOID) ((PULONG) ElementFound + 3); 
}
