#pragma once

struct NODE;
struct TABLE;


//
//  Doubly linked list structure.  Can be used as either a list head, or
//  as link words.
//
/*
typedef struct _LIST_ENTRY {
   struct _LIST_ENTRY *Flink;
   struct _LIST_ENTRY *Blink;
} LIST_ENTRY, *PLIST_ENTRY, *RESTRICTED_POINTER PRLIST_ENTRY;
*/

typedef int (NTAPI * TABLE_COMPARE_ELEMENTS) (
    TABLE   *pTable,
    PVOID    pElement1,
    PVOID    pElement2
    );

typedef NODE * (NTAPI * TABLE_ALLOCATE_ELEMENT) (
    TABLE    *pTable, 
    ULONG    TotalElementSize
    );
    
typedef void (NTAPI * TABLE_FREE_ELEMENT) (
    TABLE    *pTable, 
    PVOID    Element
    );

struct NODE
{
  NODE                     *ParentNode;  
  NODE                     *RightChild;
  NODE                     *LeftChild;
  LIST_ENTRY               LLEntry;
  ULONG                    Unknown;
};

struct TABLE
{
  NODE                     *TopNode;
  LIST_ENTRY               LLHead;
  LIST_ENTRY               *LastElementFound;
  ULONG                    LastElementIndex;
  ULONG                    NumberOfElements;
  TABLE_COMPARE_ELEMENTS   CompareElements;
  TABLE_ALLOCATE_ELEMENT   AllocateElement;
  TABLE_FREE_ELEMENT       FreeElement;
  ULONG                    Unknown;
};

extern "C"
{
void NTAPI RtlInitializeGenericTable(
    TABLE *pGenericTable, 
    TABLE_COMPARE_ELEMENTS CompareElements, 
    TABLE_ALLOCATE_ELEMENT AllocateElement, 
    TABLE_FREE_ELEMENT FreeElement, 
    ULONG Unknown
    );

ULONG NTAPI RtlNumberGenericTableElements(
    TABLE *pGenericTable
    );

BOOLEAN NTAPI RtlIsGenericTableEmpty(
    TABLE *pGenericTable
    );

PVOID NTAPI RtlGetElementGenericTable(
    TABLE *pGenericTable, 
    ULONG ElementNumber
    );

PVOID NTAPI RtlInsertElementGenericTable(
    TABLE *pGenericTable, 
    PVOID ElementData, 
    ULONG DataLength, 
    OUT BOOLEAN *IsNewElement
    );

PVOID NTAPI RtlLookupElementGenericTable(
    TABLE *pGenericTable, 
    PVOID ElementToFind
    );

BOOLEAN NTAPI RtlDeleteElementGenericTable(
    TABLE *pGenericTable, 
    PVOID ElementToDelete
    );
};
