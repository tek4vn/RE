// generictable.cpp: Defines the entry point for the console application.
//

#include <windows.h>
#include <stdio.h>
#include "generictable.h"

int __stdcall CompareItems(TABLE *pTable, PVOID ItemToCompare, PVOID ItemInList)
{
  if (*(PULONG) ItemToCompare > *(PULONG) ItemInList)
    return 0; // Return zero if ItemToCompare > ItemInList
  else if (*(PULONG) ItemToCompare < *(PULONG) ItemInList)
    return 1; // Return one if ItemToCompare < ItemInList
  else
    return -1; // Return minus one if ItemToCompare == ItemInList
}

NODE * __stdcall TableAllocateCallback(TABLE *pTable, ULONG ByteToAllocate)
{
	NODE *pItem = (NODE *)malloc(ByteToAllocate);
	return pItem;
}

void __stdcall TableFreeCallback(TABLE *pTable, PVOID Item)
{
	free(Item);
}

int main()
{
	TABLE Table;
	ULONG ItemsToAdd = 5000;
	RtlInitializeGenericTable(&Table, CompareItems, TableAllocateCallback, TableFreeCallback, NULL);
	// Add 5000 random values to table. Make sure there are 5000 unique values:
	while (ItemsToAdd--)
	{
	  BOOLEAN bNewItem = FALSE;
	  int Item = rand();
	  
	  PVOID p = RtlInsertElementGenericTable(&Table, &Item, 4, &bNewItem);
	  if (bNewItem == FALSE)
	    ItemsToAdd++;
	    
	  printf ("%x\n", (DWORD) p);
	}
	
	// Dump the entire table in the order in which it was created (the linked list
	// order, not the tree order):
	
	for (int i = 0; i < 5000; i ++)
	{
	  int *Item = (int *)RtlGetElementGenericTable(&Table, 0);
	  if (Item)
	  {
	    printf ("%d\n", *Item);
	    RtlDeleteElementGenericTable(&Table, Item);
	  }
	}
	return i;
}
