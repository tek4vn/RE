// BengalyKeygen.cpp : Defines the entry point for the console application.
//


#include <stdio.h>
#include <tchar.h>
#include <windows.h>

ULONG ComputeSerial(LPSTR pszString)
{
  DWORD dwLen = lstrlen(pszString);
  _asm
  {
    xor esi, esi
    mov ecx, [dwLen]
    mov edx, 0x25
    mov eax, 1
LoopStart:
    MOV EBX,DWORD PTR [pszString]
    mov ebx, dword ptr [ebx]
    //MOVSX EDX,BYTE PTR DS:[EAX+40351F]
    SUB EBX,EDX
    IMUL EBX,EDX
    MOV ESI,EBX
    SUB EBX,EAX
    ADD EBX, 0x4353543
    ADD ESI,EBX
    XOR ESI,EDX
    MOV EAX,4
    mov edx, 0x65
    DEC ECX
    JNZ LoopStart
    mov eax, ESI
  }
}

int _tmain(int argc, _TCHAR* argv[])
{
  printf ("Welcome to the KeygenMe-3 keygen!\n");
  if (argc == 2)
  {
    printf ("User name is: %s\n", argv[1]);
    printf ("Serial number is: %u\n", ComputeSerial(argv[1]));
  }

	return 0;
}

