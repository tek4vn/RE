// DefenderBF.cpp : Brute-forces two encrypted functions in Defender.EXE
// to obtain their decryption keys.
//

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>

unsigned long dwEncryptedData1[] = {    //First function
0x5AA37BEB,    0xD7321D42,    0x2618DDF9,    0x2F1794E3,
0x1DE51172,    0x8BDBD150,    0xBB2954C1,    0x678CB4E3,
0x5DD701F9,    0xE11679A6,    0x501CD9A0,    0x685251B9,
0xD6F355EE,    0xE401D07F,    0x10C218A5,    0x22593307,
0x10133778,    0x22594B07,    0x1E134B78,    0xC5093727,
0xB016083D,    0x8A4C8DAC,    0x1BB759E3,    0x550A5611,
0x140D1DF4,    0xE8CE15C5,    0x47326D27,    0xF3F1AD7D,
0x42FB734C,    0xF34DF691,    0xAB07368B,    0xE5B2080F,
0xCDC6C492,    0x5BF8458B,    0x8B55C3C9 };    

unsigned long dwEncryptedData2[] = {    // Second Function
0x92DC5BE6,    0xC24AE922,    0x4C9BF108,    0xA322A0CA,
0x5E9A857C,    0xA224E39E,    0x5896832E,    0xB710A6CD,
0x56B58376,    0xF90BE194,    0x4325E45C,    0x3F3409BA,
0x7566F387,    0x9BB75741,    0x50EF52C3,    0x1E7BDCC1,
0xE4AAE180,    0xAA3E6F65,    0x2C415226,    0xB3E5565B,
0xB6F41612,    0x78450FDD,    0xF2DC091F,    0x97C94154,
0xD95DCF99,    0xDE840AD8,    0x81BECF5F,    0x0FABAF1E,
0x7E10AAB6,    0x4805FA8B,    0xC694DF36,    0x57A3DF7D,
0x9CB5DAFF,    0x1264DFC1,    0x62D93303,    0xFEBBC93E,
0xC95BC84D }; 

unsigned char Sequence[] = {0xC7, 0x45, 0xFC, 0x00, 0x00, 0x00, 0x00 };

void BruteForce(unsigned long * pdwDataBlock, unsigned long dwLength, unsigned char *pSequence, unsigned long dwSequenceLength)
{
  unsigned long dwCurrentKey = 0;
  unsigned long dwBlockCount = dwLength;
  unsigned long *pdwDecryptedData = (unsigned long *) malloc(dwLength * sizeof(unsigned long));
  unsigned long dwPrevBlock = 0;
  for (dwCurrentKey = 0; dwCurrentKey < 0xffffffff; dwCurrentKey++)
  {
    // Decrypt the block using the current key:
    for (unsigned long dwCurrentBlock = 0; dwCurrentBlock <= dwBlockCount; dwCurrentBlock++)
    {      
      pdwDecryptedData[dwCurrentBlock] = pdwDataBlock[dwCurrentBlock] ^ dwCurrentKey;
      pdwDecryptedData[dwCurrentBlock] ^= dwPrevBlock;
      dwPrevBlock = pdwDataBlock[dwCurrentBlock];
    }
    
    // Search for our token in the decrypted block:
    unsigned char * pbCurrent = (unsigned char *) memchr(pdwDecryptedData, pSequence[0] , dwLength * sizeof(unsigned long));
    while (pbCurrent)
    {      
      if (memcmp(pbCurrent, pSequence, dwSequenceLength) == 0)
      {
        printf ("Found our sequence! Key is 0x%08x.\n", dwCurrentKey);
        return;
      }
      pbCurrent = (unsigned char *) memchr(pbCurrent + 1, pSequence[0] , dwLength * sizeof(unsigned long) - (pbCurrent - (unsigned char *) pdwDecryptedData));
    }
  }
  
  free(pdwDecryptedData);
}

int main(int argc, char* argv[])
{
  BruteForce(dwEncryptedData1, sizeof(dwEncryptedData1) / sizeof(unsigned long), Sequence, sizeof(Sequence));
  BruteForce(dwEncryptedData2, sizeof(dwEncryptedData2) / sizeof(unsigned long), Sequence, sizeof(Sequence));

	return 0;
}


