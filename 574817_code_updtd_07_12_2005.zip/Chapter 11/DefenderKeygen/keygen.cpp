// keygen.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <tchar.h>
#include <windows.h>

ULONGLONG  NameToInt64(LPWSTR pwszName)
{
  ULONGLONG Result = 0;
  int iPosition = 0;
  while (*pwszName)
  {
    Result += (ULONGLONG) *pwszName << (ULONGLONG) (*pwszName % 48);    
    pwszName++;
    iPosition++;
  }
  
  return Result;
}

extern "C" int _tmain(int argc, _TCHAR* argv[])
{
  char name[256];
  char fsname[256];
  DWORD complength;
  DWORD VolumeSerialNumber;
  
  if (argc != 2)
  {
    printf ("Usage: DefenderKeygen <User Name>\n");
    exit(1);
  }
  
  GetVolumeInformation("C:\\", name, sizeof(name), &VolumeSerialNumber, &complength, 0, fsname, sizeof(fsname));
  printf ("Volume serial number is: 0x%08x\n", VolumeSerialNumber);
  printf ("Computing serial for name: %s\n", argv[1]);
  WCHAR wszName[256];
  mbstowcs(wszName, argv[1], 256);
  ULONGLONG Name = NameToInt64(wszName);
  ULONG FirstNum = (ULONG) Name * VolumeSerialNumber;
  ULONGLONG Result = FirstNum - (ULONG) 0xb14ac01a;
  Result |= (ULONGLONG) (FirstNum - 0x8ed105c2) << 32;
  
  printf ("Name number is: %08x%08x\n", (ULONG) (Name >> 32), (ULONG) Name);
  printf ("Name * VolumeSerialNumber is: %08x\n", FirstNum);
  printf ("Serial number is: %08x%08x\n", (ULONG) (Result >> 32), (ULONG) Result);
  
	return 0;
}

